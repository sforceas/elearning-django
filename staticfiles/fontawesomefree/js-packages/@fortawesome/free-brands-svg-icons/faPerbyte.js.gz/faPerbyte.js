'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'perbyte';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'e083';
var svgPathData = 'M305.3 284.6H246.6V383.3h58.71q24.42 0 38.19-13.77t13.77-36.11q0-21.83-14.03-35.33T305.3 284.6zM149.4 128.7H90.72v98.72h58.71q24.42 0 38.19-13.77t13.77-36.11q0-21.83-14.03-35.34T149.4 128.7zM366.6 32H81.35A81.44 81.44 0 000 113.4V398.6A81.44 81.44 0 0081.35 480H366.6A81.44 81.44 0 00448 398.6V113.4A81.44 81.44 0 00366.6 32zm63.63 366.6a63.71 63.71 0 01-63.63 63.63H81.35a63.71 63.71 0 01-63.63-63.63V113.4A63.71 63.71 0 0181.35 49.72H366.6a63.71 63.71 0 0163.63 63.63zM305.3 128.7H246.6v98.72h58.71q24.42 0 38.19-13.77t13.77-36.11q0-21.83-14.03-35.34T305.3 128.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPerbyte = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;