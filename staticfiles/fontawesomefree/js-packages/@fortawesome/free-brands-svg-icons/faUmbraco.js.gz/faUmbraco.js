'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'umbraco';
var width = 510;
var height = 512;
var aliases = [''];
var unicode = 'f8e8';
var svgPathData = 'M255.4 8C118.4 7.83 7.14 118.7 7 255.7c-.07 137 111 248.2 248 248.3 136.9 0 247.8-110.7 248-247.7S392.3 8.17 255.4 8zm145 266q-1.14 40.68-14 65t-43.51 35q-30.61 10.7-85.45 10.47h-4.6q-54.78 .22-85.44-10.47t-43.52-35q-12.85-24.36-14-65a224.8 224.8 0 010-30.71 418.4 418.4 0 013.6-43.88c1.88-13.39 3.57-22.58 5.4-32 1-4.88 1.28-6.42 1.82-8.45a5.09 5.09 0 014.9-3.89h.69l32 5a5.07 5.07 0 014.16 5 5 5 0 010 .77l-1.7 8.78q-2.41 13.25-4.84 33.68a380.6 380.6 0 00-2.64 42.15q-.28 40.43 8.13 59.83a43.87 43.87 0 0031.31 25.18A243 243 0 00250 340.6h10.25a242.6 242.6 0 0057.27-5.16 43.86 43.86 0 0031.15-25.23q8.53-19.42 8.13-59.78a388 388 0 00-2.6-42.15q-2.48-20.38-4.89-33.68l-1.69-8.78a5 5 0 010-.77 5 5 0 014.2-5l32-5h.82a5 5 0 014.9 3.89c.55 2.05 .81 3.57 1.83 8.45 1.82 9.62 3.52 18.78 5.39 32a415.7 415.7 0 013.61 43.88 228.1 228.1 0 01-.04 30.73z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faUmbraco = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;