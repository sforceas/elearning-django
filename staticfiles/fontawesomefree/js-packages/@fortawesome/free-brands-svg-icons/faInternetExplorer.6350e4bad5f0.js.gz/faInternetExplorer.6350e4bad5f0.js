'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'internet-explorer';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f26b';
var svgPathData = 'M483 159.7c10.85-24.58 21.42-60.44 21.42-87.87 0-72.72-79.64-98.37-209.7-38.58-107.6-7.181-211.2 73.67-237.1 186.5 30.85-34.86 78.27-82.3 121.1-101.2C125.4 166.9 79.13 228 43.99 291.7 23.25 329.7 0 390.9 0 436.7c0 98.57 92.85 86.5 180.3 42.01 31.42 15.43 66.56 15.57 101.7 15.57 97.12 0 184.2-54.29 216.8-146H377.9c-52.51 88.59-196.8 52.1-196.8-47.44H509.9c6.407-43.58-1.655-95.71-26.85-141.2zM64.56 346.9c17.71 51.15 53.7 95.87 100.3 123.3-88.74 48.94-173.3 29.1-100.3-123.3zm115.1-108.9c2-55.15 50.28-94.87 103.1-94.87 53.42 0 101.1 39.72 103.1 94.87H180.5zm184.5-187.6c21.42-10.29 48.56-22 72.56-22 31.42 0 54.27 21.72 54.27 53.72 0 20-7.427 49.01-14.57 67.87-26.28-42.29-65.99-81.58-112.3-99.59z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faInternetExplorer = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;