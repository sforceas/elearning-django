'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'wirsindhanderk';
var width = 512;
var height = 512;
var aliases = ['wsh'];
var unicode = 'e2d0';
var svgPathData = 'M50.77 479.8h83.36V367.8l-83.36 47.01zm329 0h82.35V414.9l-82.35-47.01zm.0057-448V251.6L256.2 179.2 134.5 251.6V31.81H50.77V392.6L256.2 270.3 462.2 392.6V31.81z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWirsindhanderk = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;