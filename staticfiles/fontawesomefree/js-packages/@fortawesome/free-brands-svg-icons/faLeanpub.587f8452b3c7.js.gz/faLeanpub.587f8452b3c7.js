'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'leanpub';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f212';
var svgPathData = 'M386.5 111.5l15.1 248.1-10.98-.275c-36.23-.824-71.64 8.783-102.7 27.1-31.02-19.21-66.42-27.1-102.7-27.1-45.56 0-82.07 10.7-123.5 27.72L93.12 129.6c28.55-11.8 61.48-18.11 92.23-18.11 41.17 0 73.84 13.18 102.7 42.54 27.72-28.27 59.01-41.72 98.54-42.54zM569.1 448c-25.53 0-47.49-5.215-70.54-15.65-34.31-15.65-69.99-24.98-107.9-24.98-38.98 0-74.93 12.9-102.7 40.62-27.72-27.72-63.68-40.62-102.7-40.62-37.88 0-73.56 9.333-107.9 24.98C55.24 442.2 32.73 448 8.303 448H6.93L49.47 98.86C88.73 76.63 136.5 64 181.8 64 218.8 64 256.1 71.68 288 93.1 319 71.68 357.2 64 394.2 64c45.29 0 93.05 12.63 132.3 34.86L569.1 448zm-43.37-44.74l-34.04-280.2c-30.74-13.1-67.25-21.41-101-21.41-38.43 0-74.39 12.08-102.7 38.7-28.27-26.63-64.23-38.7-102.7-38.7-33.76 0-70.27 7.411-101 21.41L50.3 403.3c47.21-19.49 82.89-33.49 135-33.49 37.6 0 70.82 9.606 102.7 29.64 31.84-20.04 65.05-29.64 102.7-29.64 52.15 0 87.83 13.1 135 33.49z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLeanpub = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;