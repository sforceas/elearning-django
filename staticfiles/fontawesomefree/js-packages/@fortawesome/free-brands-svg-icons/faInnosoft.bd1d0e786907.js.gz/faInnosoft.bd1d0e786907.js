'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'innosoft';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'e080';
var svgPathData = 'M422.6 159.7a27.38 27.38 0 00-13.87-23.34 26.42 26.42 0 00-26.21 .133L73.94 314.6V176.3a11.95 11.95 0 016.047-10.34L218.1 86.21a12.15 12.15 0 0111.92 .025l32.66 18.85L112.6 191.7v56L359.6 105.1 241.1 36.68c-10.99-6.129-22.3-6.255-33.8-.27l-164.6 95.03c-10.63 6.12-16.77 16.39-17.29 29.12l0 191.5c.17 10.14 5.08 18.67 13.47 23.43a27.04 27.04 0 0026.74-.045L374.1 197.4V335.7a11.98 11.98 0 01-5.92 10.37L230 425.8a12.18 12.18 0 01-11.94 .062l-32.72-18.9 150.1-86.63v-56L88.37 406.9l118.8 68.58a33.88 33.88 0 0034.25-.327l164.5-94.1c10.75-6.631 16.65-17.12 16.62-29.53z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faInnosoft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;