'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'wpbeginner';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f297';
var svgPathData = 'M462.8 322.4C519 386.7 466.1 480 370.9 480c-39.6 0-78.82-17.69-100.1-50.04-6.887 .356-22.7 .356-29.59 0C219.8 462.4 180.6 480 141.1 480c-95.49 0-148.3-92.1-91.86-157.6C-29.92 190.5 80.48 32 256 32c175.6 0 285.9 158.6 206.8 290.4zm-339.6-82.97h41.53v-58.08h-41.53v58.08zm217.2 86.07v-23.84c-60.51 20.92-132.4 9.198-187.6-33.97l.246 24.9c51.1 46.37 131.7 57.88 187.3 32.91zm-150.8-86.07h166.1v-58.08H189.6v58.08z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWpbeginner = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;