'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'tripadvisor';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f262';
var svgPathData = 'M528.9 178.8 576 127.6H471.7a326.1 326.1 0 00-367 0H0l47.09 51.24A143.9 143.9 0 00241.9 390.7L288 440.9l46.11-50.17A143.9 143.9 0 00575.9 285.2h-.03A143.6 143.6 0 00528.9 178.8zM144.1 382.6a97.39 97.39 0 1197.39-97.39A97.39 97.39 0 01144.1 382.6zM288 282.4c0-64.09-46.62-119.1-108.1-142.6a281 281 0 01216.2 0C334.6 163.3 288 218.3 288 282.4zm143.9 100.2h-.01a97.4 97.4 0 11.01 0zM144.1 234.1h-.01a51.06 51.06 0 1051.06 51.06v-.11A51 51 0 00144.1 234.1zm287.8 0a51.06 51.06 0 1051.06 51.06A51.06 51.06 0 00431.9 234.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTripadvisor = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;