'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'buy-n-large';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f8a6';
var svgPathData = 'M288 32C133.3 32 7.79 132.3 7.79 256S133.3 480 288 480s280.2-100.3 280.2-224S442.7 32 288 32zm-85.39 357.2L64.1 390.5l77.25-290.7h133.4c63.15 0 84.93 28.65 78 72.84a60.24 60.24 0 01-1.5 6.85 77.39 77.39 0 00-17.21-1.93c-42.35 0-76.69 33.88-76.69 75.65 0 37.14 27.14 68 62.93 74.45-18.24 37.16-56.16 60.92-117.7 61.52zM358 207.1h32l-22.16 90.31h-35.41l-11.19-35.63-7.83 35.63h-37.83l26.63-90.31h31.34l15 36.75zm145.9 182.1H306.8L322.6 328a78.8 78.8 0 0011.47 .83c42.34 0 76.69-33.87 76.69-75.65 0-32.65-21-60.46-50.38-71.06l21.33-82.35h92.5l-53.05 205.4h103.9zM211.7 269.4H187l-13.8 56.47h24.7c16.14 0 32.11-3.18 37.94-26.65 5.56-22.31-7.99-29.82-24.14-29.82zM233 170h-21.34L200 217.7h21.37c18 0 35.38-14.64 39.21-30.14C265.2 168.7 251.1 170 233 170z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBuyNLarge = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;