'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'unity';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'e049';
var svgPathData = 'M498.1 206.4 445.3 14.72 248.2 66.08 219 116.1l-59.2-.43L15.54 256 159.8 396.3l59.17-.43 29.24 50 197.1 51.36 52.8-191.6-30-49.63zM223.8 124.2 374.5 86.51 288 232.3H114.9zm0 263.6L114.9 279.7H288l86.55 145.8zm193 14L330.2 256l86.58-145.8L458.6 256z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faUnity = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;