'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'wallet';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f555';
var svgPathData = 'M448 128H80C71.13 128 64 120.9 64 112S71.13 96 80 96H480V80C480 53.49 458.5 32 432 32H64C28.65 32 0 60.65 0 96v320c0 35.34 28.65 64 64 64h384c35.35 0 64-28.66 64-64V192C512 156.7 483.3 128 448 128zM416 336c-17.62 0-32-14.38-32-32s14.38-32 32-32s32 14.38 32 32S433.6 336 416 336z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWallet = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;