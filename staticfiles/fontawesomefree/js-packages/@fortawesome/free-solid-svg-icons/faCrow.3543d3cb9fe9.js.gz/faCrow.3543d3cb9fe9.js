'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'crow';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f520';
var svgPathData = 'M544 32L527.6 32C513 12.63 490.1 0 464 0C419.9 0 384 35.88 384 80v21L12.12 393.6c-7.625 5.625-12.12 14.62-12.12 24.12c0 22.5 23.62 37 43.75 27l121.5-60.76l96.5 .0054l44.38 120.1c2.375 6.25 9.25 9.375 15.38 7.125l22.62-8.25c6.25-2.25 9.375-9.125 7.125-15.38L313 384L352 384c1.875 0 3.75-.2513 5.625-.2513l44.5 120.4c2.375 6.25 9.25 9.375 15.38 7.125l22.62-8.25c6.25-2.25 9.375-9.125 7.125-15.38l-41.24-111.5C485.8 352.8 544 279.3 544 192V112l96-16C640 60.63 597 32 544 32zM464 104c-13.25 0-24-10.75-24-24s10.75-24 24-24s24 10.75 24 24S477.2 104 464 104z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCrow = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;