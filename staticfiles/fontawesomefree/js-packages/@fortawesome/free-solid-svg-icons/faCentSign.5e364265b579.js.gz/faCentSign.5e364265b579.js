'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cent-sign';
var width = 320;
var height = 512;
var aliases = [''];
var unicode = 'e0e0';
var svgPathData = 'M312.6 359.6c11.31 13.58 9.469 33.75-4.125 45.06C283.2 425.7 254.1 438.8 224 444.6V480c0 17.67-14.31 32-32 32s-32-14.33-32-32v-34.56c-38.43-6.088-75.34-23.77-104.9-53.9c-73.31-74.73-73.31-196.4 0-271.1C84.62 90.32 121.6 72.83 160 66.74V32c0-17.67 14.31-32 32-32s32 14.33 32 32v35.77c30.04 5.83 59.18 18.52 84.47 39.58c13.59 11.31 15.44 31.48 4.125 45.06c-11.34 13.58-31.5 15.45-45.06 4.125c-49.66-41.36-121.3-37.59-166.7 8.734c-49.06 50.03-49.06 131.4 0 181.5c45.41 46.34 117.1 50.08 166.7 8.734C281.1 344.1 301.3 346 312.6 359.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCentSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;