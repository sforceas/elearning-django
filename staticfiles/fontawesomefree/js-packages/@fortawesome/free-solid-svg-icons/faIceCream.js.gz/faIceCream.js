'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'ice-cream';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f810';
var svgPathData = 'M195.4 493.7C200.5 504.9 211.8 511.1 224 511.1s23.5-7.126 28.62-18.25L352 287.1H96L195.4 493.7zM368 160.1h-1c.6437-5.545 .9598-11.08 .9598-16.57c0-36.61-29.23-143.6-143.1-143.6c-115.7 0-143.1 107.2-143.1 143.6c0 5.496 .3162 11.03 .9598 16.57H80c-26.5 0-48.04 21.48-48.04 47.94s21.36 47.92 47.86 47.92h288.4c26.5 0 47.86-21.46 47.86-47.92S394.5 160.1 368 160.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faIceCream = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;