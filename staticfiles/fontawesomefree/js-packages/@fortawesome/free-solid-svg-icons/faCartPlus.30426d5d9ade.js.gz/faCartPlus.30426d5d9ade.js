'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cart-plus';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f217';
var svgPathData = 'M176 416c-26.51 0-47.1 21.49-47.1 48S149.5 512 176 512s47.1-21.49 47.1-48S202.5 416 176 416zM569.5 44.73C563.4 36.64 554.1 32 543.1 32H121.1L119.6 19.51C117.4 8.191 107.5 0 96 0H23.1C10.75 0 0 10.75 0 23.1S10.75 48 23.1 48h52.14l60.28 316.5C138.6 375.8 148.5 384 160 384H488c13.25 0 24-10.75 24-23.1C512 346.7 501.3 336 488 336H179.9L170.7 288h318.4c14.29 0 26.84-9.47 30.77-23.21l54.86-191.1C577.5 63.05 575.6 52.83 569.5 44.73zM416 160c0 11.31-9.256 20.57-20.57 20.57h-38.86v38.85C356.6 230.7 347.3 240 336 240s-20.57-9.258-20.57-20.57V180.6H276.6C265.3 180.6 256 171.3 256 160s9.256-20.57 20.57-20.57h38.86V100.6c0-11.31 9.258-20.57 20.57-20.57s20.57 9.256 20.57 20.57v38.85h38.86C406.7 139.4 416 148.7 416 160zM463.1 416c-26.51 0-47.1 21.49-47.1 48s21.49 48 47.1 48s47.1-21.49 47.1-48S490.5 416 463.1 416z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCartPlus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;