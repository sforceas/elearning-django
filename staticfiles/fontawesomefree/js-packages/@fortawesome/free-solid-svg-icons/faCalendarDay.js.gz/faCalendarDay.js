'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'calendar-day';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f783';
var svgPathData = 'M0 464C0 490.5 21.5 512 48 512h352c26.5 0 48-21.5 48-48V192H0V464zM64 272C64 263.3 71.25 256 80 256h96C184.8 256 192 263.3 192 272v96C192 376.8 184.8 384 176 384h-96C71.25 384 64 376.8 64 368V272zM400 64H352V31.1C352 14.4 337.6 0 320 0C302.4 0 288 14.4 288 31.1V64H160V31.1C160 14.4 145.6 0 128 0S96 14.4 96 31.1V64H48C21.49 64 0 85.49 0 112V160h448V112C448 85.49 426.5 64 400 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCalendarDay = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;