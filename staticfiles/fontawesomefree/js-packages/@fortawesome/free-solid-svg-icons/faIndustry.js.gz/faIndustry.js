'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'industry';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f275';
var svgPathData = 'M512 152v295.1c0 17.67-14.33 32-32 32H32c-17.67 0-32-14.33-32-32v-384c0-17.67 14.33-32 32-32h96c17.67 0 32 14.33 32 32v160l139.1-92.24C315.1 121.6 336 133.1 336 152V223.1l139.1-92.24C491.1 121.6 512 133.1 512 152z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faIndustry = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;