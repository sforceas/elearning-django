'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'vihara';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f6a7';
var svgPathData = 'M632.9 400.8L543.1 352l.0007-64l55.12-17.75c11.88-5.875 11.88-22.62 0-28.5L479.1 192l.0005-64l27.25-16.25c7.75-7.75 5.625-20.75-4.125-25.63L320 0L136.9 86.13C127.1 91 125 104 132.8 111.8L160 128l.0005 64L40.88 241.8c-11.88 5.875-11.88 22.62 0 28.5L96 288l.0007 64l-88.87 48.75C1.758 404.4-.6145 410.4 .1355 416c.625 5 3.622 9.75 8.747 12.38L64 448l-.0007 48c0 8.875 7.125 16 15.1 16h31.1c8.875 0 15.1-7.125 15.1-16V448h159.1v48c0 8.875 7.124 16 15.1 16h31.1c8.875 0 15.1-7.125 15.1-16V448h159.1v48c0 8.875 7.127 16 16 16h31.1c8.875 0 15.1-7.125 15.1-16L575.1 448l55.12-19.62C636.2 425.8 639.2 421 639.9 416C640.6 410.4 638.2 404.4 632.9 400.8zM224 128h191.1v64H224V128zM479.1 352h-319.1V288h319.1V352z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faVihara = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;