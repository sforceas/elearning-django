'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'location-arrow';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f124';
var svgPathData = 'M444.4 98.21l-143.1 351.1C292.9 468.5 275.2 480 256 480c-28.84 0-48.02-23.1-48.02-47.1v-159.1H48c-22.94 0-42.67-16.22-47.09-38.75c-4.437-22.5 7.688-44.1 28.92-53.69l351.1-143.1c17.86-7.343 38.45-3.188 52.11 10.5C447.6 59.74 451.8 80.3 444.4 98.21z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLocationArrow = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;