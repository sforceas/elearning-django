'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'fill';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f575';
var svgPathData = 'M502.6 217L294.1 9.375C288.7 3.125 280.5 0 272.3 0c-8.125 0-16.4 3.125-22.52 9.375L168.1 91l-81.63-81.65C74.01-3.14 53.76-3.112 41.31 9.408C28.87 21.91 28.9 42.13 41.37 54.6l81.5 81.53L28.13 230.1c-37.5 37.38-37.5 98.25 0 135.7l117.1 117.1C164 502.6 188.6 512 213.1 512c24.62 0 49.13-9.375 67.88-28.12l221.6-221.6C515.1 249.8 515.1 229.5 502.6 217zM386.4 288H65.92c1.375-3.75 3.597-8.012 7.472-11.76l94.7-94.76l49.25 49.12c12.5 12.5 32.75 12.5 45.25 0s12.5-32.75 0-45.25l-49.19-49.11l58.91-58.98l162.4 162.4L386.4 288z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFill = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;