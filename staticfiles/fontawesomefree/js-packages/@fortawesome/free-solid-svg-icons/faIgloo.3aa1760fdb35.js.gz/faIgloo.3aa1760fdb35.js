'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'igloo';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f7ae';
var svgPathData = 'M320 33.87C309.5 32.74 298.8 32 288 32c-99.75 0-187.8 50.73-239.4 127.1L320 159.1V33.87zM352 39.37v120.6l175.4-.0049C487.3 99.86 424.8 55.87 352 39.37zM480 319.1l95.1 .002c0-46-11.14-89.38-30.26-128L480 191.1V319.1zM96 191.1L30.26 191.1c-19.12 38.63-30.26 82-30.26 128L96 319.1V191.1zM400 320L448 319.1V191.1H128v127.1L176 320v31.99L0 351.1V432C0 458.5 21.49 480 48 480l160-.0146l-.0001-139.4c0-41.85 30.11-79.98 71.75-84.15C327.6 251.6 368 289.1 368 336v143.1L528 480c26.51 0 48-21.49 48-48v-80.01l-176 .0024V320z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faIgloo = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;