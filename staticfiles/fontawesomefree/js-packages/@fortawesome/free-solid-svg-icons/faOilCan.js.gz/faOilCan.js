'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'oil-can';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f613';
var svgPathData = 'M637.9 168c-3.484-6.062-10.5-9.103-17.36-7.65l-169.7 37.61l-49.97-30.44C392.8 162.6 383.3 160 373.3 160H288V112h48C344.8 112 352 104.8 352 96l-.0008-16c0-8.838-7.162-16-16-16H175.1c-8.836 0-15.1 7.162-15.1 16L160 96c0 8.836 7.164 16 16 16H224V160H47.1C21.53 160 0 181.5 0 208v64.3c0 19.06 11.28 36.32 28.75 43.98l67.25 29.46L96 374C96 397.2 117.5 416 143.1 416h256.8c13.89 0 27.08-5.203 36.59-14.75l198.4-214.4C640.5 181.7 641.4 174.1 637.9 168zM96 293.3L48 272.3V208h47.1L96 293.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faOilCan = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;