'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'magnet';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f076';
var svgPathData = 'M320 256c0 59.2-53.85 106-115.1 94.14C159.3 341.3 128 298.6 128 252.2V160l-128 .0003v88.2c0 113.8 81.61 215.4 194.5 229.9C331.1 495.6 448 389.2 448 256V160l-128-.0003V256zM416 31.1h-64c-17.67 0-32 14.33-32 32v64h128V63.1C448 46.33 433.7 31.1 416 31.1zM128 63.1C128 46.33 113.7 31.1 96 31.1H32c-17.67 0-32 14.33-32 32v64h128V63.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMagnet = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;