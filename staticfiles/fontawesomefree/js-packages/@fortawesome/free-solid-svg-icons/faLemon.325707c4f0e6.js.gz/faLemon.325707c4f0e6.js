'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'lemon';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f094';
var svgPathData = 'M427.9 52.1c-20.13-20.23-47.58-25.27-65.63-14.77c-51.63 30.08-158.6-46.49-281 75.91c-122.4 122.4-45.83 229.4-75.91 281c-10.5 18.05-5.471 45.5 14.77 65.63c20.13 20.24 47.58 25.27 65.63 14.77c51.63-30.08 158.6 46.49 281-75.91c122.4-122.4 45.83-229.4 75.91-281C453.2 99.69 448.1 72.23 427.9 52.1zM211.9 127.5C167.6 138.7 106.7 199.6 95.53 243.9C93.69 251.2 87.19 255.1 79.1 255.1c-1.281 0-2.594-.1562-3.906-.4687C67.53 253.4 62.34 244.7 64.47 236.1c14.16-56.28 83.31-125.4 139.6-139.6c8.656-2.031 17.25 3.062 19.44 11.62C225.7 116.7 220.5 125.3 211.9 127.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLemon = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;