'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'eraser';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f12d';
var svgPathData = 'M497.9 273.1c9.313-9.376 13.97-21.69 13.97-34s-4.655-24.63-13.97-34l-159.1-160C328.6 36.66 316.3 32 303.1 32c-12.31 0-24.62 4.656-33.1 13.97L13.97 301.1C4.655 311.4 0 323.7 0 335.1s4.655 24.63 13.97 34l95.1 96c8.965 8.965 21.17 14 33.85 14L499.1 480C506.6 480 512 474.6 512 467.1c0-28.72-23.28-52-52-52h-104.1L497.9 273.1zM195.4 211.4l137.3 137.3l-67.25 67.38H150.6L70.6 335.1L195.4 211.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faEraser = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;