'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'stamp';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f5bf';
var svgPathData = 'M32 512h448v-64H32V512zM415.1 255.1H349.5C333.1 255.1 320 242.9 320 226.5V217.1c.002-27.31 8.803-53.37 21.42-77.59c9.289-17.83 13.04-38.85 8.973-61.16c-7.051-38.65-38.74-70.35-77.47-76.93C212.4-8.841 160 37.48 160 95.99c0 14.13 3.1 27.5 8.725 39.63C182.1 164.6 192.2 195.2 191.1 227.2C191.9 243.2 178.5 255.1 162.5 255.1H96C42.98 255.1 0 298.1 0 351.1v64h512v-64C512 298.1 469 255.1 415.1 255.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faStamp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;