'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'store';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f54e';
var svgPathData = 'M483.5 256C471.3 256 459.4 254 448 250.5V384H127.9V250.5C116.5 254 104.5 256 92.35 256C86.9 256 81.45 255.6 75.1 254.9C71.82 254.4 68.02 252.8 64 251.7L64.01 464c0 26.51 21.49 48 47.1 48h352.1c26.51 0 47.1-21.49 47.1-48l.0355-212.3c-4.146 1.082-8.088 2.709-12.4 3.281C494.4 255.6 489 256 483.5 256zM547.6 103.8l-57.32-90.68c-5.105-8.15-14.21-13.13-23.93-13.13H109.6c-9.717 0-18.82 4.979-23.93 13.13L28.33 103.8c-29.59 46.83-3.41 111.9 51.9 119.4C84.21 223.7 88.3 224 92.36 224c26.14 0 49.29-11.38 65.19-28.97C173.4 212.6 196.7 224 222.7 224c26.14 0 49.29-11.38 65.19-28.97C303.8 212.6 327 224 353.1 224c26.17 0 49.29-11.38 65.19-28.97C434.2 212.6 457.4 224 483.4 224c4.141 0 8.113-.2734 12.09-.793C551 215.8 577.3 150.7 547.6 103.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faStore = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;