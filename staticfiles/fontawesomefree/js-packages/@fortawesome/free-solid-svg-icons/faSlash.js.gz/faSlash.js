'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'slash';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f715';
var svgPathData = 'M24.03 0c5.156 0 10.37 1.672 14.78 5.109l591.1 463.1c10.44 8.172 12.25 23.27 4.062 33.7c-8.125 10.41-23.19 12.28-33.69 4.078L9.189 42.89c-10.44-8.172-12.25-23.27-4.062-33.7C9.845 3.156 16.91 0 24.03 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;