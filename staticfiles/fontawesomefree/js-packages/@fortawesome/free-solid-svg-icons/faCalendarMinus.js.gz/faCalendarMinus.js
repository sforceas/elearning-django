'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'calendar-minus';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f272';
var svgPathData = 'M400 64H352V31.1C352 14.4 337.6 0 320 0C302.4 0 288 14.4 288 31.1V64H160V31.1C160 14.4 145.6 0 128 0S96 14.4 96 31.1V64H48C21.49 64 0 85.49 0 112V160h448V112C448 85.49 426.5 64 400 64zM0 464C0 490.5 21.5 512 48 512h352c26.5 0 48-21.5 48-48V192H0V464zM143.1 328h160C317.3 328 328 338.7 328 352s-10.74 23.1-23.1 23.1H143.1C130.7 375.1 120 365.3 120 352C120 338.7 130.7 328 143.1 328z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCalendarMinus = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;