'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'manat-sign';
var width = 384;
var height = 512;
var aliases = [''];
var unicode = 'e1d5';
var svgPathData = 'M368 272V448c0 17.69-14.33 32-32 32s-32-14.31-32-32V272c0-50.56-33.9-92.9-80-106.8V448c0 17.69-14.33 32-32 32s-32-14.31-32-32V165.2C113.9 179.1 80 221.4 80 272V448c0 17.69-14.33 32-32 32s-32-14.31-32-32V272c0-86.09 62.2-157.8 144-172.9V64c0-17.69 14.33-32 32-32s32 14.31 32 32v35.06C305.8 114.2 368 185.9 368 272z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faManatSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;