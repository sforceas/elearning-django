'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'fish';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f578';
var svgPathData = 'M327.1 48c-90 0-168.6 71.23-212.3 132.2l-87.3-79.45C15.41 88.67-2.7 101.4 .3374 119.7L28.8 256L.3374 392.3c-3.038 18.28 15.08 31.02 27.11 19.09l87.3-79.52C158.5 392.8 237.1 464 327.1 464C464.5 464 576 297.6 576 256S464.5 48 327.1 48zM416 288c-17.67 0-32-14.34-32-32c0-17.67 14.33-32 32-32s32 14.33 32 32C448 273.7 433.7 288 416 288z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFish = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;