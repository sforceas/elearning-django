'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'candy-cane';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f786';
var svgPathData = 'M497.5 91.1C469.6 33.13 411.8 0 352.4 0c-27.88 0-56.14 7.25-81.77 22.62L243.1 38.1C227.9 48.12 223 67.75 232.1 82.87l32.76 54.87c8.522 14.2 27.59 20.6 43.88 11.06l27.51-16.37c5.125-3.125 10.95-4.439 16.58-4.439c10.88 0 21.35 5.625 27.35 15.62c9 15.12 3.917 34.59-11.08 43.71L15.6 397.6c-15.25 9.125-20.13 28.62-11 43.87l32.76 54.87c8.522 14.2 27.59 20.66 43.88 11.12l347.4-206.5C500.2 258.1 533.2 167.5 497.5 91.1zM319.7 104.1L317.2 106.5l-20.5-61.5c9.75-4.75 19.88-8.125 30.38-10.25l20.63 61.87C337.8 97.37 328.2 99.87 319.7 104.1zM145.8 431.7l-60.5-38.5l30.88-18.25l60.5 38.5L145.8 431.7zM253.3 367.9l-60.5-38.5l30.88-18.25l60.5 38.5L253.3 367.9zM364.2 301.1L303.7 263.5l30.88-18.25l60.5 38.5L364.2 301.1zM384.7 104.7l46-45.1c8.375 6.5 16 13.1 22.5 22.5l-45.63 45.81C401.9 117.8 393.9 110.1 384.7 104.7zM466.7 212.5l-59.5-19.75c3.25-5.375 5.875-10.1 7.5-17.12c1-4.5 1.625-9.125 1.75-13.62l60.38 20.12C474.7 192.5 471.4 202.7 466.7 212.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCandyCane = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;