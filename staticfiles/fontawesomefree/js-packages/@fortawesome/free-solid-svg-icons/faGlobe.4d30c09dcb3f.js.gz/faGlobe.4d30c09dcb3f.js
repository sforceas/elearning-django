'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'globe';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f0ac';
var svgPathData = 'M186.8 26.24C119.1 46.6 64.08 96.01 36.1 160h99.97C145.7 104.1 163.6 57.44 186.8 26.24zM160 256c0 22.55 1.277 43.86 3.623 64h184.8c2.346-20.14 3.623-41.45 3.623-64s-1.277-43.86-3.623-64H163.6C161.3 212.1 160 233.5 160 256zM343.6 160c-16.25-88.04-53.37-144-87.57-144S184.7 71.96 168.4 160H343.6zM475.9 160c-27.98-63.99-83-113.4-150.7-133.8C348.4 57.44 366.3 104.1 375.9 160H475.9zM325.2 485.8C392.9 465.4 447.9 415.1 475.9 352h-99.97C366.3 407.9 348.4 454.6 325.2 485.8zM487.1 192h-106.6c2.248 20.5 3.485 41.84 3.485 64s-1.237 43.5-3.485 64h106.6c5.641-20.4 8.894-41.8 8.894-64S492.7 212.4 487.1 192zM168.4 352c16.25 88.04 53.37 144 87.57 144s71.32-55.96 87.57-144H168.4zM128 256c0-22.16 1.237-43.5 3.485-64H24.89c-5.641 20.4-8.895 41.8-8.895 64s3.254 43.6 8.895 64H131.5C129.2 299.5 128 278.2 128 256zM36.1 352c27.98 63.99 82.1 113.4 150.7 133.8C163.6 454.6 145.7 407.9 136.1 352H36.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGlobe = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;