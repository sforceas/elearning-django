'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cloud';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f0c2';
var svgPathData = 'M640 352c0 70.7-57.31 128-128 128H144C64.5 480 0 415.5 0 336c0-62.8 40.2-116.2 96.2-135.9C96.11 197.4 96 194.7 96 192c0-88.41 71.59-160 160-160c59.31 0 111 32.2 138.7 80.2C409.9 102 428.3 96 448 96c53 0 96 43 96 96c0 12.2-2.312 23.91-6.406 34.59C596 238.4 640 290.1 640 352z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCloud = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;