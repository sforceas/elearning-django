'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'calendar-week';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f784';
var svgPathData = 'M400 64H352V31.1C352 14.4 337.6 0 320 0C302.4 0 288 14.4 288 31.1V64H160V31.1C160 14.4 145.6 0 128 0S96 14.4 96 31.1V64H48c-26.51 0-48 21.49-48 48L0 160h448l.0002-48C448 85.49 426.5 64 400 64zM.0002 464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48L448 192H0L.0002 464zM64 272C64 263.3 71.25 256 80 256h288C376.8 256 384 263.3 384 272v64c0 8.75-7.25 16-15.1 16h-288C71.25 352 64 344.8 64 336V272z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCalendarWeek = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;