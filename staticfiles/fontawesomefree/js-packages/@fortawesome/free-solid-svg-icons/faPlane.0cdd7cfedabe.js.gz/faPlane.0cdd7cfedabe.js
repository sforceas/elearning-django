'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'plane';
var width = 576;
var height = 512;
var aliases = [''];
var unicode = 'f072';
var svgPathData = 'M246.7 0c5.125 0 11.34 3.609 13.9 8.062L365.7 192h114.3C515.3 192 576 220.7 576 256s-60.66 64-96 64h-114.3l-105.1 183.9C257.7 508.9 252.4 512 246.7 512H181.2c-10.63 0-18.31-10.19-15.37-20.41L214.9 320H111.1l-43.19 57.59C65.77 381.6 61.02 384 55.99 384h-40c-10.41 0-18.03-9.781-15.5-19.88L31.99 256L.4885 147.9C-2.043 137.8 5.582 128 15.99 128h40c5.031 0 9.781 2.375 12.81 6.406L111.1 192h102.9L165.8 20.39C162.9 10.17 170.6 0 181.2 0H246.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPlane = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;