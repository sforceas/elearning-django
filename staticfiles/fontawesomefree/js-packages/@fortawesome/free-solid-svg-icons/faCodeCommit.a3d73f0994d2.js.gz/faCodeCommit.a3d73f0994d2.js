'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'code-commit';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f386';
var svgPathData = 'M608 224h-131.2C461.9 150.1 397.4 96 320 96S178.1 150.1 163.2 224H32C14.33 224 0 238.3 0 256s14.33 32 32 32h131.2C178.1 361 242.6 416 320 416s141.9-54.97 156.8-128H608c17.67 0 32-14.33 32-32S625.7 224 608 224zM320 336c-44.11 0-80-35.89-80-80S275.9 176 320 176s80 35.89 80 80S364.1 336 320 336z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCodeCommit = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;