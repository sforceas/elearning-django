'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'box';
var width = 448;
var height = 512;
var aliases = [''];
var unicode = 'f466';
var svgPathData = 'M447.6 158.8l-56.38-104.9C386.9 40.75 374.8 32 360.9 32H240v128h206.8C447.1 159.5 447.3 159.3 447.6 158.8zM0 192v240C0 458.5 21.49 480 48 480h352c26.51 0 48-21.49 48-48V192H0zM208 160V32H87.13c-13.88 0-26 8.75-30.38 21.88L.375 158.8C.75 159.3 .875 159.5 1.25 160H208z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;