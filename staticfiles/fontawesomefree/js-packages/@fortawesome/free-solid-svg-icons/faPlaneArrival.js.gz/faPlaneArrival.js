'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'plane-arrival';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f5af';
var svgPathData = 'M44.75 205.5L133.5 285.5c7.375 6.625 16 11.37 25.5 13.1l287.6 78.36c26.5 7.123 54.5 8.623 80.1 1.25c29.62-8.25 43.38-21.12 47.25-35.62s-1.75-32.74-23.38-54.99c-19.25-19.87-44.37-32.74-70.87-39.99l-97.5-26.5L282.7 30.2c-1.5-5.875-5.875-10.37-11.62-11.1L205.1 .582C195.5-2.291 185.1 5.832 185.4 16.96l47.87 164.2L130.1 153.3L103.5 85.44c-2-4.875-6-8.5-11-9.875L52.75 64.7C42.38 61.82 32.25 69.7 32 80.57l.25 101.7C32.38 191.3 38.25 199.7 44.75 205.5zM608 448H31.1C14.33 448 0 462.3 0 479.1S14.33 512 31.1 512h576C625.7 512 640 497.7 640 480S625.7 448 608 448z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPlaneArrival = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;