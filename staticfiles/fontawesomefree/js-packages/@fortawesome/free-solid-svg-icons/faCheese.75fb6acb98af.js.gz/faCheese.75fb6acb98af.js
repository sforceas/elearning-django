'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cheese';
var width = 512;
var height = 512;
var aliases = [''];
var unicode = 'f7ef';
var svgPathData = 'M0 288v159.1C0 465.6 14.38 480 32 480h448c17.62 0 32-14.38 32-31.1V288H0zM299.9 32.01c-7.75-.25-15.25 2.25-21.12 6.1L0 255.1l512-.0118C512 136.1 417.1 38.26 299.9 32.01z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCheese = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;