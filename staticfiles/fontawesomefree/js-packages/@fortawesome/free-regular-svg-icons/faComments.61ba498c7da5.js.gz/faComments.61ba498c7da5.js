'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'far';
var iconName = 'comments';
var width = 640;
var height = 512;
var aliases = [''];
var unicode = 'f086';
var svgPathData = 'M416 176C416 78.8 322.9 0 208 0S0 78.8 0 176c0 41.63 17.18 79.81 45.73 109.9c-16.34 31.43-38.47 55.57-38.99 55.96c-6.746 7.15-8.635 17.81-4.721 26.98C5.93 378.1 14.97 384 24.95 384c54.18 0 98.32-19.24 128.1-38.22C171.2 349.7 189.3 352 208 352C322.9 352 416 273.2 416 176zM208 304c-14.16 0-28.77-1.689-43.41-5.021L145.4 294.6l-16.72 10.35c-17 10.52-34.42 18.39-52.14 23.57c4.184-6.668 8.191-13.57 11.77-20.45l15.78-30.34L80.57 252.9C65.71 237.3 48 211.2 48 176c0-70.58 71.78-128 160-128s160 57.42 160 128S296.2 304 208 304zM599.6 443.7C624.8 413.9 640 376.6 640 336C640 238.8 554 160 448 160c-.3145 0-.6191 .041-.9336 .043C447.5 165.3 448 170.6 448 176c0 98.62-79.68 181.2-186.1 202.5C282.7 455.1 357.1 512 448 512c33.69 0 65.32-8.008 92.85-21.98C565.2 502 596.1 512 632.3 512c3.059 0 5.76-1.725 7.02-4.605c1.229-2.879 .6582-6.148-1.441-8.354C637.6 498.7 615.9 475.3 599.6 443.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faComments = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;